var canvas = document.getElementById("Score1");
var ctx = canvas.getContext("2d");
ctx.font = "30px Arial";
ctx.fillText("SCORE:",10,50);

var canvas = document.getElementById("Score2");
var ctx = canvas.getContext("2d");
ctx.font = "30px Arial";
ctx.fillText("SCORE:",10,50);